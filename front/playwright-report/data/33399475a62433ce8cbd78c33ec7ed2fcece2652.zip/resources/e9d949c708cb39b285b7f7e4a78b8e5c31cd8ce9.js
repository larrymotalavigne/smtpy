"use strict";
(self["webpackChunksmtpy_frontend"] = self["webpackChunksmtpy_frontend"] || []).push([["main"],{

/***/ 92:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppComponent: () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 2596);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 4460);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 1567);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);






function AppComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 4)(1, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "SMTPy");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 6)(4, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Fonctionnalit\u00E9s");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Tarifs");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_div_1_Template_div_click_8_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.navigateTo("/dashboard"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Connexion");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "S'inscrire");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
  }
}
function AppComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 9)(1, "div", 10)(2, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_div_2_Template_div_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.navigateTo("/dashboard"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "\uD83D\uDCCA Aper\u00E7u");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_div_2_Template_div_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.navigateTo("/domains"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "\uD83C\uDF10 Domaines");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_div_2_Template_div_click_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.navigateTo("/messages"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "\uD83D\uDCE7 Alias");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_div_2_Template_div_click_8_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.navigateTo("/statistics"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "\uD83D\uDCC8 Statistiques");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "\u2699\uFE0F Param\u00E8tres");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_div_2_Template_div_click_12_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.navigateTo("/billing"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13, "\uD83D\uDCB3 Facturation");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "router-outlet");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx_r1.currentRoute === "dashboard");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx_r1.currentRoute === "domains");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx_r1.currentRoute === "messages");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx_r1.currentRoute === "statistics");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("active", ctx_r1.currentRoute === "billing");
  }
}
function AppComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "router-outlet");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
class AppComponent {
  constructor(router) {
    this.router = router;
    this.title = 'SMTPy';
    this.currentRoute = '';
    this.showNavigation = false;
    this.showSidebar = false;
  }
  ngOnInit() {
    // Listen to route changes
    this.router.events.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.filter)(event => event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__.NavigationEnd)).subscribe(event => {
      this.updateLayoutVisibility(event.url);
    });
    // Set initial route
    this.updateLayoutVisibility(this.router.url);
  }
  updateLayoutVisibility(url) {
    this.currentRoute = url.replace('/', '') || 'landing';
    // Show navigation bar only on landing page
    this.showNavigation = this.currentRoute === 'landing';
    // Show sidebar on dashboard pages
    this.showSidebar = ['dashboard', 'domains', 'messages', 'statistics', 'billing'].includes(this.currentRoute);
  }
  navigateTo(route) {
    this.router.navigate([route]);
  }
  static {
    this.ɵfac = function AppComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: AppComponent,
      selectors: [["app-root"]],
      decls: 4,
      vars: 3,
      consts: [[1, "min-h-screen", 2, "background", "#f5f5f5", "color", "#333", "font-family", "Arial, sans-serif"], ["class", "nav-wireframe", "style", "display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #eee; padding: 15px 20px; background: white;", 4, "ngIf"], ["class", "dashboard-grid", "style", "display: grid; grid-template-columns: 250px 1fr; gap: 20px; min-height: 500px; padding: 20px;", 4, "ngIf"], [4, "ngIf"], [1, "nav-wireframe", 2, "display", "flex", "justify-content", "space-between", "align-items", "center", "border-bottom", "2px solid #eee", "padding", "15px 20px", "background", "white"], [1, "logo", 2, "background", "#3498db", "color", "white", "padding", "10px 20px", "border-radius", "4px", "font-weight", "bold"], [1, "nav-items", 2, "display", "flex", "gap", "20px"], [1, "nav-item", 2, "padding", "8px 15px", "border", "1px solid #ddd", "border-radius", "4px", "background", "#f8f9fa", "cursor", "pointer"], [1, "nav-item", 2, "padding", "8px 15px", "border", "1px solid #ddd", "border-radius", "4px", "background", "#f8f9fa", "cursor", "pointer", 3, "click"], [1, "dashboard-grid", 2, "display", "grid", "grid-template-columns", "250px 1fr", "gap", "20px", "min-height", "500px", "padding", "20px"], [1, "sidebar", 2, "background", "#f8f9fa", "border-radius", "6px", "padding", "20px"], [1, "sidebar-item", 2, "padding", "12px 15px", "margin-bottom", "5px", "border-radius", "4px", "background", "white", "border-left", "4px solid transparent", "cursor", "pointer", 3, "click"], [1, "sidebar-item", 2, "padding", "12px 15px", "margin-bottom", "5px", "border-radius", "4px", "background", "white", "border-left", "4px solid transparent", "cursor", "pointer"], [1, "main-content", 2, "background", "white", "border-radius", "6px", "padding", "20px"]],
      template: function AppComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, AppComponent_div_1_Template, 12, 0, "div", 1)(2, AppComponent_div_2_Template, 16, 10, "div", 2)(3, AppComponent_div_3_Template, 2, 0, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showNavigation);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showSidebar);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.showSidebar);
        }
      },
      dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterOutlet, _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf],
      styles: [".app-container[_ngcontent-%COMP%] {\n  @apply min-h-screen bg-gray-50;\n}\n\n.app-header[_ngcontent-%COMP%] {\n  @apply border-b border-gray-200 bg-white shadow-sm;\n}\n\n.app-main[_ngcontent-%COMP%] {\n  @apply flex-1 p-4;\n}\n\n  .p-menubar {\n  @apply border-b border-gray-200;\n}\n  .p-menubar-root-list {\n  @apply gap-2;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQTtFQUNFLDhCQUFBO0FBRkY7O0FBS0E7RUFDRSxrREFBQTtBQUZGOztBQUtBO0VBQ0UsaUJBQUE7QUFGRjs7QUFPRTtFQUNFLCtCQUFBO0FBSko7QUFPRTtFQUNFLFlBQUE7QUFMSiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb21wb25lbnQtc3BlY2lmaWMgc3R5bGVzIGZvciBBcHBDb21wb25lbnRcbi8vIFVzaW5nIFRhaWx3aW5kQ1NTIGNsYXNzZXMgaW4gdGVtcGxhdGUsIG1pbmltYWwgU0NTUyBuZWVkZWRcblxuLmFwcC1jb250YWluZXIge1xuICBAYXBwbHkgbWluLWgtc2NyZWVuIGJnLWdyYXktNTA7XG59XG5cbi5hcHAtaGVhZGVyIHtcbiAgQGFwcGx5IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBzaGFkb3ctc207XG59XG5cbi5hcHAtbWFpbiB7XG4gIEBhcHBseSBmbGV4LTEgcC00O1xufVxuXG4vLyBQcmltZU5HIGN1c3RvbWl6YXRpb25zXG46Om5nLWRlZXAge1xuICAucC1tZW51YmFyIHtcbiAgICBAYXBwbHkgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwO1xuICB9XG5cbiAgLnAtbWVudWJhci1yb290LWxpc3Qge1xuICAgIEBhcHBseSBnYXAtMjtcbiAgfVxufSJdfQ== */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBO0VBQ0UsOEJBQUE7QUFGRjs7QUFLQTtFQUNFLGtEQUFBO0FBRkY7O0FBS0E7RUFDRSxpQkFBQTtBQUZGOztBQU9FO0VBQ0UsK0JBQUE7QUFKSjtBQU9FO0VBQ0UsWUFBQTtBQUxKO0FBQ0EsNDZCQUE0NkIiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb21wb25lbnQtc3BlY2lmaWMgc3R5bGVzIGZvciBBcHBDb21wb25lbnRcbi8vIFVzaW5nIFRhaWx3aW5kQ1NTIGNsYXNzZXMgaW4gdGVtcGxhdGUsIG1pbmltYWwgU0NTUyBuZWVkZWRcblxuLmFwcC1jb250YWluZXIge1xuICBAYXBwbHkgbWluLWgtc2NyZWVuIGJnLWdyYXktNTA7XG59XG5cbi5hcHAtaGVhZGVyIHtcbiAgQGFwcGx5IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBzaGFkb3ctc207XG59XG5cbi5hcHAtbWFpbiB7XG4gIEBhcHBseSBmbGV4LTEgcC00O1xufVxuXG4vLyBQcmltZU5HIGN1c3RvbWl6YXRpb25zXG46Om5nLWRlZXAge1xuICAucC1tZW51YmFyIHtcbiAgICBAYXBwbHkgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwO1xuICB9XG5cbiAgLnAtbWVudWJhci1yb290LWxpc3Qge1xuICAgIEBhcHBseSBnYXAtMjtcbiAgfVxufSJdLCJzb3VyY2VSb290IjoiIn0= */", ".sidebar-item.active[_ngcontent-%COMP%] {\n  border-left-color: #3498db !important;\n  background: #e3f2fd !important;\n}\n\n@media (max-width: 768px) {\n  .dashboard-grid[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr !important;\n  }\n  .nav-wireframe[_ngcontent-%COMP%] {\n    flex-direction: column !important;\n    gap: 15px !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLHFDQUFBO0VBQ0EsOEJBQUE7QUFBRjs7QUFHQTtFQUNFO0lBQ0UscUNBQUE7RUFBRjtFQUdBO0lBQ0UsaUNBQUE7SUFDQSxvQkFBQTtFQURGO0FBQ0YiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5odG1sIiwic291cmNlc0NvbnRlbnQiOlsiXG4uc2lkZWJhci1pdGVtLmFjdGl2ZSB7XG4gIGJvcmRlci1sZWZ0LWNvbG9yOiAjMzQ5OGRiICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6ICNlM2YyZmQgIWltcG9ydGFudDtcbn1cblxuQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XG4gIC5kYXNoYm9hcmQtZ3JpZCB7XG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgIWltcG9ydGFudDtcbiAgfVxuICBcbiAgLm5hdi13aXJlZnJhbWUge1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW4gIWltcG9ydGFudDtcbiAgICBnYXA6IDE1cHggIWltcG9ydGFudDtcbiAgfVxufVxuIl19 */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvYXBwLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UscUNBQUE7RUFDQSw4QkFBQTtBQUFGOztBQUdBO0VBQ0U7SUFDRSxxQ0FBQTtFQUFGO0VBR0E7SUFDRSxpQ0FBQTtJQUNBLG9CQUFBO0VBREY7QUFDRjtBQUNBLDR1QkFBNHVCIiwic291cmNlc0NvbnRlbnQiOlsiXG4uc2lkZWJhci1pdGVtLmFjdGl2ZSB7XG4gIGJvcmRlci1sZWZ0LWNvbG9yOiAjMzQ5OGRiICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6ICNlM2YyZmQgIWltcG9ydGFudDtcbn1cblxuQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XG4gIC5kYXNoYm9hcmQtZ3JpZCB7XG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgIWltcG9ydGFudDtcbiAgfVxuICBcbiAgLm5hdi13aXJlZnJhbWUge1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW4gIWltcG9ydGFudDtcbiAgICBnYXA6IDE1cHggIWltcG9ydGFudDtcbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 3622:
/*!*******************************************************!*\
  !*** ./src/app/core/interceptors/auth.interceptor.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   authInterceptor: () => (/* binding */ authInterceptor)
/* harmony export */ });
/**
 * Auth interceptor to add credentials to all HTTP requests
 * This ensures session cookies are sent with every request to the backend
 *
 * The backend uses HTTP-only session cookies for authentication,
 * so we need to set withCredentials: true on all requests
 */
const authInterceptor = (req, next) => {
  // Clone the request and add withCredentials for cookie handling
  const authReq = req.clone({
    withCredentials: true
  });
  return next(authReq);
};

/***/ }),

/***/ 4429:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ 9736);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 8431);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 9648);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/platform-browser/animations */ 3835);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/api */ 7780);
/* harmony import */ var primeng_config__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/config */ 2746);
/* harmony import */ var _primeuix_themes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @primeuix/themes */ 968);
/* harmony import */ var _primeuix_themes_aura__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @primeuix/themes/aura */ 9104);
/* harmony import */ var _app_core_interceptors_auth_interceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/core/interceptors/auth.interceptor */ 3622);
/* harmony import */ var _app_core_interceptors_error_interceptor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app/core/interceptors/error.interceptor */ 9446);
/* harmony import */ var _app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/core/guards/auth.guard */ 4978);
/* harmony import */ var _app_app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.component */ 92);




// PrimeNG Services & Theme





// Interceptors


// Guards


// Routes from app-routing.module.ts
const routes = [{
  path: '',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("src_app_features_landing_landing_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/landing/landing.component */ 2282)).then(m => m.LandingComponent)
}, {
  path: 'auth/login',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputtext_mjs-node_modules_primeng_fesm2022_pri-094661"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-checkbox_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-message_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-password_mjs"), __webpack_require__.e("src_app_features_auth_login_login_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/auth/login/login.component */ 461)).then(m => m.LoginComponent),
  canActivate: [_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.guestGuard] // Redirect to dashboard if already authenticated
}, {
  path: 'auth/register',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputtext_mjs-node_modules_primeng_fesm2022_pri-094661"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-checkbox_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-message_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-password_mjs"), __webpack_require__.e("src_app_features_auth_register_register_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/auth/register/register.component */ 3165)).then(m => m.RegisterComponent),
  canActivate: [_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.guestGuard] // Redirect to dashboard if already authenticated
}, {
  path: 'auth/forgot-password',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputtext_mjs-node_modules_primeng_fesm2022_pri-094661"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-message_mjs"), __webpack_require__.e("src_app_features_auth_forgot-password_forgot-password_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/auth/forgot-password/forgot-password.component */ 7049)).then(m => m.ForgotPasswordComponent),
  canActivate: [_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.guestGuard] // Redirect to dashboard if already authenticated
}, {
  path: 'auth/reset-password',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputtext_mjs-node_modules_primeng_fesm2022_pri-094661"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-message_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-password_mjs"), __webpack_require__.e("src_app_features_auth_reset-password_reset-password_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/auth/reset-password/reset-password.component */ 6113)).then(m => m.ResetPasswordComponent),
  canActivate: [_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.guestGuard] // Redirect to dashboard if already authenticated
}, {
  path: 'dashboard',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputtext_mjs-node_modules_primeng_fesm2022_pri-094661"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-checkbox_mjs"), __webpack_require__.e("default-src_app_shared_components_layout_main-layout_component_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-table_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-tag_mjs"), __webpack_require__.e("default-src_app_core_services_statistics-api_service_ts-node_modules_chart_js_dist_chart_js-n-573651"), __webpack_require__.e("common"), __webpack_require__.e("src_app_features_dashboard_dashboard_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/dashboard/dashboard.component */ 1626)).then(m => m.DashboardComponent),
  canActivate: [_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.authGuard] // Require authentication
}, {
  path: 'domains',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputtext_mjs-node_modules_primeng_fesm2022_pri-094661"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-checkbox_mjs"), __webpack_require__.e("default-src_app_shared_components_layout_main-layout_component_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-table_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-tag_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-dialog_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-confirmdialog_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-progressbar_mjs"), __webpack_require__.e("common"), __webpack_require__.e("src_app_features_domains_domains_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/domains/domains.component */ 8342)).then(m => m.DomainsComponent),
  canActivate: [_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.authGuard] // Require authentication
}, {
  path: 'messages',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputtext_mjs-node_modules_primeng_fesm2022_pri-094661"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-checkbox_mjs"), __webpack_require__.e("default-src_app_shared_components_layout_main-layout_component_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-table_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-tag_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-dialog_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-calendar_mjs-node_modules_primeng_fesm2022_prim-fe5126"), __webpack_require__.e("src_app_features_messages_messages_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/messages/messages.component */ 3188)).then(m => m.MessagesComponent),
  canActivate: [_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.authGuard] // Require authentication
}, {
  path: 'statistics',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputtext_mjs-node_modules_primeng_fesm2022_pri-094661"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-checkbox_mjs"), __webpack_require__.e("default-src_app_shared_components_layout_main-layout_component_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-table_mjs"), __webpack_require__.e("default-src_app_core_services_statistics-api_service_ts-node_modules_chart_js_dist_chart_js-n-573651"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-calendar_mjs-node_modules_primeng_fesm2022_prim-fe5126"), __webpack_require__.e("src_app_features_statistics_statistics_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/statistics/statistics.component */ 8622)).then(m => m.StatisticsComponent),
  canActivate: [_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.authGuard] // Require authentication
}, {
  path: 'billing',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputtext_mjs-node_modules_primeng_fesm2022_pri-094661"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-checkbox_mjs"), __webpack_require__.e("default-src_app_shared_components_layout_main-layout_component_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-message_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-table_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-tag_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-dialog_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-confirmdialog_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-progressbar_mjs"), __webpack_require__.e("src_app_features_billing_billing_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/billing/billing.component */ 3138)).then(m => m.BillingComponent),
  canActivate: [_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.authGuard] // Require authentication
}, {
  path: 'profile',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputtext_mjs-node_modules_primeng_fesm2022_pri-094661"), __webpack_require__.e("default-src_app_shared_components_layout_main-layout_component_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-message_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-tag_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-divider_mjs"), __webpack_require__.e("src_app_features_profile_profile_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/profile/profile.component */ 366)).then(m => m.ProfileComponent),
  canActivate: [_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.authGuard] // Require authentication
}, {
  path: 'settings',
  loadComponent: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-button_mjs-node_modules_primeng_fesm2022_primen-85878e"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-inputtext_mjs-node_modules_primeng_fesm2022_pri-094661"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-checkbox_mjs"), __webpack_require__.e("default-src_app_shared_components_layout_main-layout_component_ts"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-message_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-table_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-dialog_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-confirmdialog_mjs"), __webpack_require__.e("default-node_modules_primeng_fesm2022_primeng-divider_mjs"), __webpack_require__.e("src_app_features_settings_settings_component_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./app/features/settings/settings.component */ 2130)).then(m => m.SettingsComponent),
  canActivate: [_app_core_guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__.authGuard] // Require authentication
}, {
  path: '**',
  redirectTo: '' // Redirect to landing page instead of dashboard
}];
// Define custom theme preset with our gradient colors
const customPreset = (0,_primeuix_themes__WEBPACK_IMPORTED_MODULE_4__.definePreset)(_primeuix_themes_aura__WEBPACK_IMPORTED_MODULE_5__["default"], {
  semantic: {
    primary: {
      50: '{purple.50}',
      100: '{purple.100}',
      200: '{purple.200}',
      300: '{purple.300}',
      400: '{purple.400}',
      500: '{purple.500}',
      600: '{purple.600}',
      700: '{purple.700}',
      800: '{purple.800}',
      900: '{purple.900}',
      950: '{purple.950}'
    }
  }
});
(0,_angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__.bootstrapApplication)(_app_app_component__WEBPACK_IMPORTED_MODULE_3__.AppComponent, {
  providers: [(0,_angular_router__WEBPACK_IMPORTED_MODULE_7__.provideRouter)(routes), (0,_angular_common_http__WEBPACK_IMPORTED_MODULE_8__.provideHttpClient)((0,_angular_common_http__WEBPACK_IMPORTED_MODULE_8__.withInterceptors)([_app_core_interceptors_auth_interceptor__WEBPACK_IMPORTED_MODULE_0__.authInterceptor, _app_core_interceptors_error_interceptor__WEBPACK_IMPORTED_MODULE_1__.errorInterceptor])), (0,_angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_9__.provideAnimations)(), (0,primeng_config__WEBPACK_IMPORTED_MODULE_10__.providePrimeNG)({
    theme: {
      preset: customPreset,
      options: {
        prefix: 'p',
        darkModeSelector: '.dark-theme',
        cssLayer: false
      }
    },
    ripple: true
  }), primeng_api__WEBPACK_IMPORTED_MODULE_11__.MessageService, primeng_api__WEBPACK_IMPORTED_MODULE_11__.ConfirmationService]
}).catch(err => console.error(err));

/***/ }),

/***/ 4978:
/*!*******************************************!*\
  !*** ./src/app/core/guards/auth.guard.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   adminGuard: () => (/* binding */ adminGuard),
/* harmony export */   authGuard: () => (/* binding */ authGuard),
/* harmony export */   guestGuard: () => (/* binding */ guestGuard)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 2596);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/auth.service */ 8010);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 4334);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 271);




/**
 * Auth guard to protect routes that require authentication
 * Redirects to login page if user is not authenticated
 */
const authGuard = (route, state) => {
  const authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService);
  const router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router);
  return authService.currentUser$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)(user => {
    if (user) {
      // User is authenticated, allow access
      return true;
    } else {
      // User is not authenticated, redirect to login
      router.navigate(['/auth/login'], {
        queryParams: {
          returnUrl: state.url
        }
      });
      return false;
    }
  }));
};
/**
 * Guest guard to prevent authenticated users from accessing auth pages
 * Redirects to dashboard if user is already authenticated
 */
const guestGuard = (route, state) => {
  const authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService);
  const router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router);
  return authService.currentUser$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)(user => {
    if (!user) {
      // User is not authenticated, allow access to auth pages
      return true;
    } else {
      // User is already authenticated, redirect to dashboard
      router.navigate(['/dashboard']);
      return false;
    }
  }));
};
/**
 * Admin guard to protect routes that require admin role
 * Redirects to dashboard if user is not an admin
 */
const adminGuard = (route, state) => {
  const authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService);
  const router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router);
  return authService.currentUser$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.take)(1), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)(user => {
    if (user && user.role === 'admin') {
      // User is admin, allow access
      return true;
    } else if (user) {
      // User is authenticated but not admin, redirect to dashboard
      router.navigate(['/dashboard']);
      return false;
    } else {
      // User is not authenticated, redirect to login
      router.navigate(['/auth/login'], {
        queryParams: {
          returnUrl: state.url
        }
      });
      return false;
    }
  }));
};

/***/ }),

/***/ 5312:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   environment: () => (/* binding */ environment)
/* harmony export */ });
const environment = {
  production: false,
  apiUrl: 'http://localhost:8000',
  appName: 'SMTPy',
  version: '2.0.0'
};

/***/ }),

/***/ 8010:
/*!***********************************************!*\
  !*** ./src/app/core/services/auth.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthService: () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 5797);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 8764);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 1318);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 9452);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../environments/environment */ 5312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 9648);




class AuthService {
  constructor(http) {
    this.http = http;
    this.apiUrl = `${_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.apiUrl}/auth`;
    this.currentUserSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    this.currentUser$ = this.currentUserSubject.asObservable();
    // Check if user is already logged in on app start
    this.checkAuthStatus().subscribe();
  }
  login(credentials) {
    return this.http.post(`${this.apiUrl}/login`, credentials).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data?.user) {
        this.currentUserSubject.next(response.data.user);
        // Session is managed via HTTP-only cookies by the auth interceptor
      }
    }));
  }
  register(userData) {
    return this.http.post(`${this.apiUrl}/register`, userData).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data?.user) {
        this.currentUserSubject.next(response.data.user);
      }
    }));
  }
  logout() {
    return this.http.post(`${this.apiUrl}/logout`, {}).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(() => {
      this.currentUserSubject.next(null);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(() => {
      // Even if logout fails on server, clear local state
      this.currentUserSubject.next(null);
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)({
        success: true,
        data: null
      });
    }));
  }
  checkAuthStatus() {
    return this.http.get(`${this.apiUrl}/me`).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(response => {
      if (response.success && response.data) {
        this.currentUserSubject.next(response.data);
      } else {
        this.currentUserSubject.next(null);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(() => {
      this.currentUserSubject.next(null);
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)({
        success: false,
        data: undefined
      });
    }));
  }
  requestPasswordReset(email) {
    return this.http.post(`${this.apiUrl}/request-password-reset`, {
      email
    });
  }
  resetPassword(token, newPassword) {
    return this.http.post(`${this.apiUrl}/reset-password`, {
      token,
      new_password: newPassword
    });
  }
  isAuthenticated() {
    return this.currentUserSubject.value !== null;
  }
  getCurrentUser() {
    return this.currentUserSubject.value;
  }
  isAdmin() {
    const user = this.getCurrentUser();
    return user?.role === 'admin';
  }
  static {
    this.ɵfac = function AuthService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || AuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({
      token: AuthService,
      factory: AuthService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 9446:
/*!********************************************************!*\
  !*** ./src/app/core/interceptors/error.interceptor.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   errorInterceptor: () => (/* binding */ errorInterceptor)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 7919);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 1318);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 2596);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/api */ 7780);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/auth.service */ 8010);






const errorInterceptor = (req, next) => {
  const router = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router);
  const messageService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(primeng_api__WEBPACK_IMPORTED_MODULE_3__.MessageService);
  const authService = (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.inject)(_services_auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService);
  return next(req).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.catchError)(error => {
    let errorMessage = 'An unexpected error occurred';
    let errorDetail = '';
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = 'Network error occurred';
      errorDetail = error.error.message;
    } else {
      // Server-side error
      switch (error.status) {
        case 400:
          errorMessage = 'Bad request';
          if (error.error?.detail) {
            errorDetail = error.error.detail;
          } else if (error.error?.field_errors) {
            // Handle validation errors
            const fieldErrors = error.error.field_errors;
            const errors = Object.keys(fieldErrors).map(key => `${key}: ${fieldErrors[key].join(', ')}`).join('; ');
            errorDetail = errors;
          }
          break;
        case 401:
          errorMessage = 'Authentication required';
          errorDetail = 'Please log in to continue';
          // Clear auth state and redirect to login
          authService.logout().subscribe();
          router.navigate(['/auth/login']);
          break;
        case 403:
          errorMessage = 'Access denied';
          errorDetail = 'You do not have permission to perform this action';
          break;
        case 404:
          errorMessage = 'Resource not found';
          errorDetail = 'The requested resource could not be found';
          break;
        case 422:
          errorMessage = 'Validation error';
          if (error.error?.detail) {
            errorDetail = error.error.detail;
          }
          break;
        case 429:
          errorMessage = 'Too many requests';
          errorDetail = 'Please wait before making another request';
          break;
        case 500:
          errorMessage = 'Server error';
          errorDetail = 'An internal server error occurred';
          break;
        case 503:
          errorMessage = 'Service unavailable';
          errorDetail = 'The service is temporarily unavailable';
          break;
        default:
          errorMessage = `HTTP Error ${error.status}`;
          errorDetail = error.error?.detail || error.message || 'Unknown error occurred';
      }
    }
    // Show error notification (except for 401 which redirects)
    if (error.status !== 401) {
      messageService.add({
        severity: 'error',
        summary: errorMessage,
        detail: errorDetail,
        life: 5000
      });
    }
    // Return the error to be handled by the component if needed
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.throwError)(() => ({
      status: error.status,
      message: errorMessage,
      detail: errorDetail,
      originalError: error
    }));
  }));
};

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(886), __webpack_exec__(4429)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map